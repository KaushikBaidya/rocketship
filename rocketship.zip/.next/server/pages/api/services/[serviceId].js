"use strict";
(() => {
var exports = {};
exports.id = 657;
exports.ids = [657];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 1655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(125);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_data_service__WEBPACK_IMPORTED_MODULE_0__);

async function handler(req, res) {
    const serviceId = req.query.serviceId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_data_service__WEBPACK_IMPORTED_MODULE_0__.getServiceById)(serviceId);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_data_service__WEBPACK_IMPORTED_MODULE_0__.deleteServiceById)(serviceId);
            res.json({
                ...result,
                message: `blog with serviceId: ${serviceId} deleted`
            });
            break;
        case "POST":
            const title = req.body.title;
            const description = req.body.description;
            result = await (0,_data_service__WEBPACK_IMPORTED_MODULE_0__.createService)(title, description);
            res.json({
                ...result,
                message: `user with userId: ${title} created`
            });
            break;
        case "PUT":
            const updateTitle = req.body.title;
            const updateDescription = req.body.description;
            result = await (0,_data_service__WEBPACK_IMPORTED_MODULE_0__.updateService)(serviceId, updateTitle, updateDescription);
            res.json({
                ...result,
                message: `blog with title: ${serviceId} updated`
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [125], () => (__webpack_exec__(1655)));
module.exports = __webpack_exports__;

})();