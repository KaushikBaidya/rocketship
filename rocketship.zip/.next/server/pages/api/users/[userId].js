"use strict";
(() => {
var exports = {};
exports.id = 582;
exports.ids = [582];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5894:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _data_user__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9552);
/* harmony import */ var _data_user__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_data_user__WEBPACK_IMPORTED_MODULE_0__);
const bcrypt = __webpack_require__(7096);

async function handler(req, res) {
    const userId = req.query.userId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_data_user__WEBPACK_IMPORTED_MODULE_0__.getUserById)(userId);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_data_user__WEBPACK_IMPORTED_MODULE_0__.deleteUserById)(userId);
            res.json({
                ...result,
                message: `user with userId: ${userId} deleted`
            });
            break;
        case "POST":
            const name = req.body.name;
            const hashedPassword = await bcrypt.hash(req.body.password, 10);
            result = await (0,_data_user__WEBPACK_IMPORTED_MODULE_0__.createUser)(name, hashedPassword);
            res.json({
                ...result,
                message: `user with userId: ${name} created`
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9552], () => (__webpack_exec__(5894)));
module.exports = __webpack_exports__;

})();