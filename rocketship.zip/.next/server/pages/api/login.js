"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 7202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const mysql = __webpack_require__(2418);
const bcrypt = __webpack_require__(7096);
async function handler(req, res) {
    if (req.method === "POST") {
        const user = req.body.name;
        const password = req.body.password;
        if (err) throw err;
        const sqlSearch = "Select * from userTable where user = ?";
        const search_query = mysql.format(sqlSearch, [
            user
        ]);
        await connection.query(search_query, async (err1, result)=>{
            connection.release();
            if (err1) throw err1;
            if (result.length == 0) {
                console.log("--------> User does not exist");
                res.sendStatus(404);
            } else {
                const hashedPassword = result[0].password;
                //get the hashedPassword from result
                if (await bcrypt.compare(password, hashedPassword)) {
                    console.log("---------> Login Successful");
                    res.send(`${user} is logged in!`);
                } else {
                    console.log("---------> Password Incorrect");
                    res.send("Password incorrect!");
                } //end of bcrypt.compare()
            } //end of User exists i.e. results.length==0
        });
    } else {
    // Handle any other HTTP method
    }
    try {} catch (e) {
        console.error(e);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7202));
module.exports = __webpack_exports__;

})();