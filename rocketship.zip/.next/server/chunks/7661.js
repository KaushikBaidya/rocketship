"use strict";
exports.id = 7661;
exports.ids = [7661];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 7661:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _interopRequireDefault = (__webpack_require__(6328)/* ["default"] */ .Z);
const _db = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(8443));
const mysql = __webpack_require__(2418);
const getBlogs = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT * FROM `blogTable`");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getBlogById = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows] = await connection.execute(`SELECT * FROM blogTable WHERE blogId = ${blogId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createBlog = async (title, description)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`INSERT INTO blogTable ( title, description) VALUES ("${title}", "${description}");`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateBlog = async (blogId, updateTitle, updateDescription)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`UPDATE blogTable SET title = "${updateTitle}", description= "${updateDescription}" WHERE blogId = ${blogId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteBlogById = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`DELETE FROM blogTable WHERE blogId = ${blogId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const blogs = {
    getBlogs,
    getBlogById,
    createBlog,
    updateBlog,
    deleteBlogById
};
module.exports = blogs;


/***/ }),

/***/ 8443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "tvcvlnrr_wp344",
    user: "tvcvlnrr_wp344",
    password: "(g@(X4S2(]cp5zP5"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ })

};
;