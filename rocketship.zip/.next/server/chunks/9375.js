"use strict";
exports.id = 9375;
exports.ids = [9375];
exports.modules = {

/***/ 9375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Detail = ()=>{
    const data = [
        {
            id: 0,
            img: "/service/4.png",
            title: "STEP 1: Application ",
            des: "Fill out a free application (FAFSA). The federal processor calculates your Expected Family Contribution (EFC). Student will be emailed a Student Aid Report (SAR). File the FAFSA and verification documents (if required)."
        },
        {
            id: 1,
            img: "/service/4.png",
            title: "STEP 2: Verification",
            des: "The Financial Aid office receives your FAFSA application. Students who are selected will receive an email from the Department of Education. Student completes verification process."
        },
        {
            id: 2,
            img: "/service/4.png",
            title: "STEP 3: Award",
            des: "Student must be accepted into chosen degree program. Eligibility for financial aid is determined. Eligible student aid recipients will receive an email notification from the University that their aid application has been processed. Financial aid is disbursed."
        }, 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-2xl mx-auto pt-10",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-[24px] text-[#211A56] font-semibold lg:text-[30px] text-center px-5 uppercase tracking-wider",
                    children: "How to Apply for Financial Aid"
                })
            }),
            data.length > 0 && data.map((item)=>// <Feature key={index.toString()} data={data} />
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "max-w-7xl mx-auto text-black px-4 lg:px-24 grid gap-y-2 py-2 lg:py-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-3 px-6 gap-x-6 items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: item.id % 2 === 0 ? "order-1 flex items-center justify-center col-span-1" : "order-2 flex items-center justify-center col-span-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: item.img,
                                    width: 350,
                                    height: 250,
                                    className: "rounded p-5 lg:p-12",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: item.id % 2 === 0 ? "order-2 text-black text-lg md:text-2xl col-span-2" : "order-1 text-black text-lg md:text-2xl col-span-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "my-5 font-semibold uppercase",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-lg",
                                        children: item.des
                                    })
                                ]
                            })
                        ]
                    })
                }, item.id))
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Detail);


/***/ })

};
;