"use strict";
exports.id = 7371;
exports.ids = [7371];
exports.modules = {

/***/ 8279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/1.ac70666c.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA9ElEQVR42mOYe+c3EwMU/H/+if//k/cCMP6NQ3cZIaxb/6X23f019drtny8f3P/z/MHeZ5s7GDbrMsBA37lfC6uu/v9fcvP//7L7///P6jr9f7vp7iMQY79sE1i76+7Tzt0v/y8+dPdP4bavf48sbvn//FLf61P7/osz/H/7WGX3lqvf+jZ/+de/4NJfn4y9f+dl5f2/eqrx89md/xUZ/v+fx7xt8cn79fN//e9Z9/9/8uQ//1dumvF/5aKY+wxQwJgVM7Wxqfn0xdlTL7zsbL/0bPWizsOrlrp3MzBMYGFYMuMuM9ybP98J////FO7NB1fymABKtYr9eBqOVQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_service_1_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8279);



const Hero = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "hidden lg:flex relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bg-yellow-200 w-40 h-40 rounded-full absolute top-36 left-20 "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bg-green-200 w-28 h-28 rounded-full absolute top-28 right-24"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bg-red-200 w-16 h-16 rounded-full absolute top-36 left-96"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-[1600px] grid grid-cols-1 lg:grid-cols-2 h-full pt-28 pb-5 lg:pb-28 mx-auto z-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mx-5 lg:mx-20 text-center lg:text-left z-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-3xl lg:text-5xl text-[#211A53] py-5 ",
                                children: "Essay Editing Services for College Admission."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-[16px] text-justify lg:text-xl p-5",
                                children: "Our start-to-finish BSN program consulting is meant to supercharge your ability to get accepted at the country’s most competitive nursing school programs. We tailor every aspect of your application to ensure the best quality right from your personal statement to your interview."
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-center mx-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-[500px]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _public_service_1_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: ""
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ })

};
;