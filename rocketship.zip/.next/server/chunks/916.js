"use strict";
exports.id = 916;
exports.ids = [916];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 8443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "tvcvlnrr_wp344",
    user: "tvcvlnrr_wp344",
    password: "(g@(X4S2(]cp5zP5"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 916:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _interopRequireDefault = (__webpack_require__(6328)/* ["default"] */ .Z);
const _db = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(8443));
const mysql = __webpack_require__(2418);
const getTestimonials = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT * FROM `testimonialTable`");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getTestimonialById = async (testimonialId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows] = await connection.execute(`SELECT * FROM testimonialTable WHERE testimonialId = ${testimonialId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createTestimonial = async (title, description)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`INSERT INTO testimonialTable ( title, description) VALUES ("${title}", "${description}");`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateTestimonial = async (testimonialId, updateTitle, updateDescription)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`UPDATE testimonialTable SET title = "${updateTitle}", description= "${updateDescription}" WHERE testimonialId = ${testimonialId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteTestimonialId = async (testimonialId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`DELETE FROM testimonialTable WHERE testimonialId = ${testimonialId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const testimonials = {
    getTestimonials,
    getTestimonialById,
    createTestimonial,
    updateTestimonial,
    deleteTestimonialId
};
module.exports = testimonials;


/***/ })

};
;