import React from "react";

const Show = () => {
  return (
    <section className="w-full bg-black text-white">
      <p>Hi</p>
    </section>
  );
};

export default Show;
