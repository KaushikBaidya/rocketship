import HomeMain from "../components/Home/HomeMain";
export default function Home() {
  return (
    <div>
      <main className="w-full relative">
        <HomeMain />
      </main>
    </div>
  );
}
